package RECURSION;

public class PrintNto1Reverse {
    static void print(int n){

        if(n==0) return ;               // Base condition: stop when n == 0

        System.out.println(n+" ");      // Print current number

        print(n-1);                     // Recursive call with n-1

    }
    public static void main(String[] args) {
        int n=5;
        print(n);
    }
}
