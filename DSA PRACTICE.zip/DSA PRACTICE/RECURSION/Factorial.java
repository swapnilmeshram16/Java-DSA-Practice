package RECURSION;

public class Factorial {

    static int Factorial(int n){

        if(n==0 || n==1) return 1;  // Base case: agar n 0 ya 1 ho, toh return 1 (kyunki 0! = 1 and 1! = 1)

        return n*Factorial(n-1);    // Recursive case: n * factorial of (n-1)
    }
    public static void main(String[] args) {
        int n=5;

        System.out.println(Factorial(n));
        
    }
}
