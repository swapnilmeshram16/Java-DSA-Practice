package RECURSION;

public class Fibonacci {

    static int fib(int n){

        if(n==0 || n==1) return n;      // Base case: agar n 0 ya 1 ho, to n return karo

        return fib(n-1) + fib(n-2);     // Recursive case: fib(n-1) + fib(n-2)
    }
    public static void main(String[] args) {
        int n=7;

        for(int i=0; i<n; i++)           // 0 se lekar n-1 tak ke Fibonacci numbers print karenge
        System.out.print(fib(i)+ " ");
    }
}
