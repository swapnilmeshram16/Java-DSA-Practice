package RECURSION;

public class DigitSum {
    static int sum(int n){
        if(n==0) return 0;          // Base case: agar number 0 ho gaya, to sum bhi 0 hoga

        return n%10 + sum(n/10);    // Last digit ka sum lo (n % 10) + remaining digits ka sum (sum(n / 10))
    }
    public static void main(String[] args) {
        int n=1234;

        System.out.println(sum(n));
    } 
}
