package RECURSION;

public class Print1ToN {

    static void print(int n){
        if(n==0) return;            // Base case: agar n 0 ho gaya, toh function ruk jaayega (aur kuch nahi karega)

        print(n-1);                 // Pehle chhote number ke liye function ko call karo

        System.out.print(n+" ");    // Jab function return hone lagega tab number print karo
                                    // Is wajah se numbers ascending order mein print honge (1 se n tak)

    }
    public static void main(String[] args) {

        int n=5;
        print(n);
    }
}
