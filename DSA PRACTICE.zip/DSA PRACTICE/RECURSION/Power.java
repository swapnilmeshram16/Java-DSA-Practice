package RECURSION;

public class Power {
    static int Power(int x, int n){
    //     if(n==0) return 1;

    //     return x* Power(x, n-1);  // Recursive step: x * x^(n-1)

    //method for more efficient optimization log(n)  
        if(n==0) return 1;  
            int half=Power(x, n/2); // Recursive call with n/2

            if(n%2==0){
                return half*half;   // If n is even: x^n = (x^(n/2))^2
            }else{
                return x*half*half; // If n is odd: x^n = x * (x^(n/2))^2
            }
    }
    public static void main(String[] args) {
        int x=2, n=4;
        System.out.println(Power(x, n));
    }
}
