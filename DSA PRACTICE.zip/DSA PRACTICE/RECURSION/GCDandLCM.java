package RECURSION;

public class GCDandLCM {
    static int gcd(int a, int b){

    //gcd
        if(b==0) return a;

        return gcd(b, a%b);
    }
    //lcm using gcd
    static int lcm(int a, int b){

        return (a*b)/gcd(a, b);
    }
    public static void main(String[] args) {
        int a=20, b=28;

        System.out.println("GCD is: "+gcd(a,b));
        System.out.println("LCM is: "+lcm(a,b));
    }
}
