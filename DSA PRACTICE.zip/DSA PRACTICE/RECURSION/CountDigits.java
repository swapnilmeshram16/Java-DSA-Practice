package RECURSION;

public class CountDigits {
    static int count(int n){

        if(n==0) return 0;      // Base case: jab number 0 ho, return 0

        return 1 + count(n/10); // Ek digit count karo, fir n ko 10 se divide karke recursive call
    }
    public static void main(String[] args) {
        int n=12345;

        System.out.println(count(n));
    }
}
