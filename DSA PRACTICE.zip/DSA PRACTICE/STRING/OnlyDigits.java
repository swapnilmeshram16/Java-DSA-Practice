package STRING;

public class OnlyDigits {
    public static void main(String[] args) {
        String s="123456";

        System.out.println(s.matches("\\d+"));
    }
}
