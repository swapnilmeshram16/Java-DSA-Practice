package STRING;

public class ReverseString {
    public static void main(String[] args) {
    String s="hellow";

    String reversed= new StringBuilder(s).reverse().toString();

    System.out.println(reversed);
    }

    // public static String reverseString(String s){
    //     return new StringBuilder(s).reverse().toString();
    // }

    //  public static void main(String[] args) {
    //     Scanner sc = new Scanner(System.in);

    //     // Taking input from the user
    //     System.out.print("Enter a string: ");
    //     String input = sc.nextLine();

    //     // Calling the reverseString method
    //     String reversed = reverseString(input);

    //     // Output
    //     System.out.println("Reversed string: " + reversed);
    // }
}

