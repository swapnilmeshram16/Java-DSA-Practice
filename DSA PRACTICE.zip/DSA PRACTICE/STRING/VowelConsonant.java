package STRING;

public class VowelConsonant {
    public static void main(String[] args) {
        String s= "hellow";

        int vovels=0, consonants=0;

        s=s.toLowerCase();

        for(char c : s.toCharArray()){

            if("aeiou".indexOf(c) != -1) vovels++; //vovel mil gya hai 

            else if(Character.isLetter(c)) consonants++; //agr char ek letter hai to vo consonant hai
        }

        System.out.println("vovels: "+vovels+ ", consonants: "+consonants);
    }
}
