package STRING;

public class RotationCheck {
    public static void main(String[] args) {
        String s1="abcd", s2="cdab";

        System.out.println((s1.length() == s2.length()) && (s1+s1).contains(s2));   //comapre array length,     add s1+s1 → "abcdabcd"
                                                                                    // .contain() check krta hai s2 iske andr hai ya nhi

        //True or false
    }
}
