package STRING;

public class PalindromeCheck {
    public static void main(String[] args) {
        String s="madam";
        String pal=new StringBuilder(s).reverse().toString();

        System.out.println(s.equals(pal));          //true or false
    }
}
