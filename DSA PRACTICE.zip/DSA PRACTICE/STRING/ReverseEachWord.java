package STRING;

public class ReverseEachWord {
    public static void main(String[] args) {
        String s="hello world";

        String[]words=s.split(" ");

        StringBuilder result=new StringBuilder();

        for(String word : words)
            result.append(new StringBuilder(word).reverse()).append(" ");   //new StringBuilder(word) creates a mutable string object for the word

            System.out.println(result.toString().trim());
            
    }
}
