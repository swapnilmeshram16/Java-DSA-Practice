package STRING;

public class CountWords {
    public static void main(String[] args) {
        String s= "I love java";

        String[]words =s.trim().split("\\s+");      // split("\\s+")->Splits by one or more spaces

        System.out.println(words.length);
    }
}
