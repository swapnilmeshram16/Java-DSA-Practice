package STRING;

import java.util.LinkedHashMap;

public class FirstUnique {
    public static void main(String[] args) {
        String s= "swiss";

        LinkedHashMap<Character, Integer>map= new LinkedHashMap<>();     // LinkedHashMap use kiya hai kyunki ye insertion order preserve karta hai

        // Step 1: Har character ka count (frequency) nikaalo
        for(char c : s.toCharArray()){
            map.put(c, map.getOrDefault(c, 0)+1);
        }

        // Step 2: First character jiska frequency 1 hai use print karo
        for(char c : map.keySet()){

            if(map.get(c)==1){      // Step 2: First character jiska frequency 1 hai use print karo
                System.out.println("first non-repeating char: "+c);
                break;
            }
        }
    }
}
