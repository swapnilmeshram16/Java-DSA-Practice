package STRING;

import java.util.Arrays;

public class AnagramCheck {
    public static void main(String[] args) {
        String s1="listen", s2="silent";

        char[] a1=s1.toCharArray(), a2=s2.toCharArray();    //Dono strings ko character arrays mein convert kar diya
        
        Arrays.sort(a1);                                    //Dono character arrays ko sort kiya (alphabetical order mein)
        Arrays.sort(a2);

        System.out.println(Arrays.equals(a1, a2));          //dono sorted arrays equal hain ya nahi
    }
}
