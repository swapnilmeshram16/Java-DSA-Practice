package STRING;

public class RemoveDuplicates {
    public static void main(String[] args) {
        String s= "programming";

        String result="";                   //empty string dor store unique char

        for(char c : s.toCharArray()){

            if(result.indexOf(c) ==-1) result+=c;
        }

        System.out.println(result);
    }
}
