package STRING;

public class SubstringCheck {
    public static void main(String[] args) {
        String s="Hello ChatGPT";

        System.out.println(s.contains("GPT"));
    }
}
