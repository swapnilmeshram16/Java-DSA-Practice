package STRING;

public class ReplaceVowels {
    public static void main(String[] args) {
        String s="programming";

        System.out.println(s.replaceAll("[aeiouAEIOU]", "*"));
    }
}
