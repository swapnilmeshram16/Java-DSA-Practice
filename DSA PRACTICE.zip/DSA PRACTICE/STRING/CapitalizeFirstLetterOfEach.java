package STRING;

public class CapitalizeFirstLetterOfEach {
    public static void main(String[] args) {
        String s= "hello world";

        String [] words= s.split(" ");      
        // String ko words me tod diya space ke basis pe
        // Example: "hello world" → ["hello", "world"]

        StringBuilder sb= new StringBuilder();
        

        for(String word : words){
            sb.append(Character.toUpperCase(word.charAt(0)))    // Har word ke pehle character ko uppercase karo 'h' → 'H'
            .append(word.substring(1))                     // aur baaki part ko as it is jod do // "ello"
            .append(" ");        // space lagana mat bhoolo
        }

        System.out.println(sb.toString().trim());
        // sb ko string me convert karke print kiya
        // trim() use kiya kyunki last me extra space aayega, usse remove karta hai
    }
}
