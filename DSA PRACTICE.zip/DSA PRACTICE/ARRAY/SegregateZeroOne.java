package ARRAY;

import java.util.Arrays;

public class SegregateZeroOne {
    public static void main(String[] args) {
        int []arr={0,1,0,1,1,0};

        int left=0, right=arr.length-1;         // Do pointers: left start se, right end se

        while(left<right){                      // Jab tak left pointer right se chhota hai

            while(arr[left]==0) left++;         // Jab tak left par 0 milta rahe, left pointer aage badhao
            while(arr[right]==1) right--;       // Jab tak right par 1 milta rahe, right pointer peeche le jao

            if(left<right){                     // Agar abhi bhi left < right hai to swap karo
               
                // Swap 1 (left) and 0 (right)
                int temp=arr[left];
                arr[left]=arr[right];
                arr[right]=temp;
            }
        }
        System.out.println(Arrays.toString(arr));
    }
}
