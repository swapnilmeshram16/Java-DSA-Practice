package ARRAY;

import java.util.HashSet;

public class Duplicates {
    public static void main(String[] args) {
        int arr[]={1,2,3,4,3,2};

        HashSet<Integer>set=new HashSet<>();            //duplicates allow nhi krta....

        for(int num:arr){

            if(!set.add(num))                           //agr set num ko add nhi krta to vo duplicate hai aur false ho jayega

            System.out.println("duplicate element is: "+num);
        }

    }
}
