package ARRAY;

import java.util.HashSet;

public class CommonElements {
    public static void main(String[] args) {
        int [] a={1,2,3}, b={2,3,4};

        HashSet<Integer>set=new HashSet<>();

        for(int num: a) set.add(num);

        for(int num: b){

            if(set.contains(num))

            System.out.println(num);
        }
    }
}
