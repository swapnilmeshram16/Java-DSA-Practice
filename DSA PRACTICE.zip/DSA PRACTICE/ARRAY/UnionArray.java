package ARRAY;

import java.util.HashSet;

public class UnionArray {
    public static void main(String[] args) {
        int [] a={1,2,3}, b={2,4,5};

        HashSet<Integer>set=new HashSet<>();        //use to store unique element 

        for(int num: a) set.add(num);
        for(int num: b) set.add(num);

        System.out.println(set);
    }
}
