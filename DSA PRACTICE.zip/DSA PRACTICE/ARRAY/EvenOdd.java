package ARRAY;

public class EvenOdd {
    public static void main(String[] args) {
        int arr[]={1,2,4,6,9};

        int even=0, odd=0;

        for(int num: arr){

            if(num%2==0) even++;

            else odd++;
        }

        System.out.println("Even: "+even+ ", Odd: "+odd);
    }
}
