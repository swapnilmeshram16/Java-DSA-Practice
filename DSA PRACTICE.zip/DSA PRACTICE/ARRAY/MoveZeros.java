package ARRAY;

import java.util.Arrays;

public class MoveZeros {
    public static void main(String[] args) {
        int arr[]={0,1,0,3,12};

        int index=0;              //index position for put non zero value

        for(int num : arr){
            if(num!=0)              // agar number zero nhi hai to
            arr[index++]=num;       //index 0 ki jagah num aur index++
        }

        while(index<arr.length)     //bche huye index pr
        arr[index++]=0;             //0 put kre index++

        System.out.println(Arrays.toString(arr));
    }
}
