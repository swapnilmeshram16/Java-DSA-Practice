package ARRAY;

import java.util.Arrays;

public class RemoveDuplicates {
    public static void main(String[] args) {
        int arr[]={1,1,2,3,3,4};
        int n=arr.length;

        int temp[]=new int[n];      //temp arr to store unique elements

        int j=0;                    //index for store unique element

        for(int i=0; i<n-1; i++){
            if(arr[i] != arr[i+1])      //check curr and next element are different

            temp[j++]=arr[i];           //if it is differnt, store in temp
        }

        temp[j++]=arr[n-1];         //last element are very important so add this for compairing

        for(int i=0; i<j; i++)
            arr[i]=temp[i];

        System.out.println(Arrays.toString(Arrays.copyOfRange(arr, 0, j)));

    }
}
