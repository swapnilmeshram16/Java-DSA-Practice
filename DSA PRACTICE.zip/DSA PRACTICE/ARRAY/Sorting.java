package ARRAY;

import java.util.Arrays;

public class Sorting {
    public static void main(String[] args) {
        int arr[]={11,1,44,22,55};

        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
    }
}
