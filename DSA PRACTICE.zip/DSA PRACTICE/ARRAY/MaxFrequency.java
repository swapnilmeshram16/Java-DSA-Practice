package ARRAY;

import java.util.HashMap;

public class MaxFrequency {
    public static void main(String[] args) {
        int arr[]={1,3,2,3,4,3};
        HashMap<Integer, Integer>freq=new HashMap<>();

        // max: maximum frequency ab tak
        // res: us element ka value jiska frequency max hai
        int max=0, res=0;

        for(int num: arr){
            int count=freq.getOrDefault(num,0)+1;   // Agar element pahle se map me hai to uska count +1, warna 0 + 1

            freq.put(num, count);   // Map me updated frequency daal do

            if(count>max){          // Agar ye element ki frequency ab tak ke max se zyada ho gayi
                max=count;          // update max frequency
                res=num;            // store current number as result
            }
        }
        System.out.println(res);
    }
}
