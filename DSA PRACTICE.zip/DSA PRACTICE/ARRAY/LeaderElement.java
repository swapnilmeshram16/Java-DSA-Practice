package ARRAY;

public class LeaderElement {
    public static void main(String[] args) {
        int arr[]={22,21,45,77,34,21};          //leader element means if the elemnt is greater than its right elemnt then it is leader

        int leader=arr[arr.length-1];           //last ele is always leader
         System.out.println(leader);

        for(int i=arr.length-2; i>=0; i--){

            if(arr[i]>leader){
                leader=arr[i];

                System.out.println(leader);
            }
        }

    }
}
