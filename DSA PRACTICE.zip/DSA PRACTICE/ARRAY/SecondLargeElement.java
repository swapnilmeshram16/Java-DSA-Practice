package ARRAY;

public class SecondLargeElement {
    public static void main(String[] args) {
        int arr[]={12,45,67,89,67};

        int first=Integer.MIN_VALUE, second=Integer.MIN_VALUE;

        for(int num: arr){
            
            if(num> first){
                second=first;
                first=num;
            }else if(num>second && num!=first){
                second=num;
            }
        }
        System.out.println("second large elemt is: "+second);
    }
}
