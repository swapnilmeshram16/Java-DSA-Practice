package SORTING;

import java.lang.reflect.Array;
import java.util.Arrays;

public class SortAscending {
    public static void main(String[] args) {
        int arr[]={4,6,2,4,8,1};

        Arrays.sort(arr);

        System.out.println(Arrays.toString(arr));
    }
}
