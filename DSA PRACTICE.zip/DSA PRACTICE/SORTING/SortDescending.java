package SORTING;

import java.util.Arrays;
import java.util.Collections;

public class SortDescending {
    public static void main(String[] args) {
        Integer arr[]={3,5,8,32,67,0};
        
        //Sort the array in descending order using Collections.reverseOrder()
        Arrays.sort(arr, Collections.reverseOrder());

        System.out.println(Arrays.toString(arr));

    }
}
