package LinkedList;


// Node class definition
class Node {
    int data;      // value stored in the node
    Node next;     // reference to the next node

    // Constructor
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class PrintList {

    static void print(Node head){

        Node temp= head;                    // start from the head node
        while(temp != null){
            System.out.print(temp.data+ " ");

            temp=temp.next;
        }

    }
    public static void main(String[] args) {
         // Creating a simple linked list manually:
        // 1 -> 2 -> 3 -> 4

        Node head = new Node(1);            // first node

        head.next= new Node(2);             // second node

        head.next.next = new Node(3);       // third node

        head.next.next.next=new Node(4);    // fourth node

        print(head);                        // Call the print function
    }
}
