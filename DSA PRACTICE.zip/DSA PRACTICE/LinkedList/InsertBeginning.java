package LinkedList;

// Node class definition
class Node {
    int data;      // value stored in the node
    Node next;     // reference to the next node

    // Constructor
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class InsertBeginning {

    static Node insertAtBeg(Node head, int data){

        Node newNode=new Node(data);            // Step 1: Create new node
        newNode.next=head;                      // Step 2: Point new node's next to current head
        return newNode;                         // Step 3: Return new node as new head
    }
    public static void main(String[] args) {
        Node head=new Node(2);
        head.next=new Node(3);

        head=insertAtBeg(head,1);           // Insert 1 at beginning: 1 -> 2 -> 3

        print(head);
    }

    static void print(Node head){               // Function to print the linked list
        while(head !=null){
            System.out.print(head.data+ " ");
            head=head.next;
        }
    }
}
