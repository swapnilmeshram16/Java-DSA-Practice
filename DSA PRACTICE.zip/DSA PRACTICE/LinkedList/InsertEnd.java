package LinkedList;

// Node class definition
class Node {
    int data;      // value stored in the node
    Node next;     // reference to the next node

    // Constructor
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}
public class InsertEnd {

    static Node insertAtEnd(Node head, int data){
        Node newNode=new Node(data);             //create a new node

            if(head==null) return newNode;       // If list is empty, return newNode as the new head

            //Traverse to the last node
            Node temp=head;
            while(temp.next != null) temp=temp.next;

            //Link last node to new node
            temp.next=newNode;
            return head;        //Return head (unchanged)

    }
    public static void main(String[] args) {
        Node head=new Node(1);
        head.next=new Node(2);

        head=insertAtEnd(head,3);

        print(head);
    }

    static void print(Node head){
       while(head != null){
        System.out.print(head.data+ " ");
        head=head.next;
       }
    }
}
